# -*- coding: utf-8 -*-
# Токен ненастоящий :) Подставьте свой
token = '1013567285:AAGHQ1VPIT0adyIK7uqw4pnuBDtbWIoezrM'